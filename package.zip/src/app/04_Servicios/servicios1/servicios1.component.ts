import { Component} from '@angular/core';
import { Usuario } from 'src/app/02_Directivas/practica-directivas/usuario.model';
import { AlertaService } from '../alerta.service';

@Component({
  selector: 'app-servicios1',
  templateUrl: './servicios1.component.html',
  styleUrls: ['./servicios1.component.css']
})

export class Servicios1Component {
  constructor(private miServicio1:AlertaService){}

  titulo:string= "Práctica directivas";
  cuadroNombre:string = "";
  cuadroApellido:string = "";
  cuadroLogin:string = "";
  cuadroPassword:string = "";
  mostrar:boolean = false;

  arrayUsuarios:Usuario[]=[
    //new Usuario("Angel", "García", "admin", "1234"),
    //new Usuario("Manolo", "González", "man222", "2222"),
    //new Usuario("Sara", "Jiménez", "sa3333", "3333")
  ]

  fn_agregaUsuario(){
    //Los datos los cogemos de los cuadros de texto del HTML
    let usuario1 = new Usuario(this.cuadroNombre, this.cuadroApellido, this.cuadroLogin, this.cuadroApellido);

    //Agregamos el nuevo usuario al array de usuarios
    this.arrayUsuarios.push(usuario1);

    this.miServicio1.mensajeAlerts();
  }



}
