import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class AlertaService {

  constructor() { }

  mensajeAlerts(){
    alert("Trabajo hecho");
  }
}
