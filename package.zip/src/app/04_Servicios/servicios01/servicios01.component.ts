import { Component } from '@angular/core';
import { AlertaService } from '../alerta.service';
import { Usuario } from './usuario.model';

@Component({
  selector: 'app-servicios01',
  templateUrl: './servicios01.component.html',
  styleUrls: ['./servicios01.component.css']
})
export class Servicios01Component{

  //Con esto inyectamos en el componente el servicio Alerta que creamos
  constructor(private miServicio:AlertaService) { }

  titulo:string= "Formulario de registro de empleados";
  cuadroNombre:string = "";
  cuadroApellido:string = "";
  cuadroLogin:string = "";
  cuadroPassword:string = "";
  mostrar:boolean = false;

  arrayUsuarios:Usuario[]=[
    //new Usuario("Angel", "García", "admin", "1234"),
    //new Usuario("Manolo", "González", "man222", "2222"),
    //new Usuario("Sara", "Jiménez", "sa3333", "3333")
  ]

  fn_agregaUsuario(){
    //Los datos los cogemos de los cuadros de texto del HTML
    let usuario1 = new Usuario(this.cuadroNombre, this.cuadroApellido, this.cuadroLogin, this.cuadroApellido);

    //Hacemos uso del servicio de Alert
    this.miServicio.muestraMensaje("Registro del empleado realizado correctamente");

    //Agregamos el nuevo usuario al array de usuarios
    this.arrayUsuarios.push(usuario1);
  }



}
