import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pipes01'
})
export class Pipes01Pipe implements PipeTransform {

  transform(value: string, ...args: unknown[]): any {
    let valor = value+"€";
    return valor;
  }

}
