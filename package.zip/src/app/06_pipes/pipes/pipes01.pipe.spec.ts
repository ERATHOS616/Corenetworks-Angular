import { Pipes01Pipe } from './pipes01.pipe';

describe('Pipes01Pipe', () => {
  it('create an instance', () => {
    const pipe = new Pipes01Pipe();
    expect(pipe).toBeTruthy();
  });
});
