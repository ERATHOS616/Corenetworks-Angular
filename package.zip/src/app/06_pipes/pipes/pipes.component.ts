import { Component, OnInit } from '@angular/core';
import { Pipe, PipeTransform } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  ejemplo1:string = 'HoLa MuNdO';
  ejemplo2:string = 'Hola mundo';
  ejemplo3:string = 'hola mundo';
  ejemplo4:string = 'HOLA MUNDO';
  cantidad:string = '234';

}
