import { Component } from '@angular/core';
import { Persona } from './persona';

@Component({
  selector: 'app-binding-bidireccional02',
  templateUrl: './binding-bidireccional02.component.html',
  styleUrls: ['./binding-bidireccional02.component.css']
})
export class BindingBidireccional02Component {

  persona:Persona;
  constructor() {
   this.persona= new Persona();
   this.persona.nombre="gema";
   this.persona.edad=20;
  }


}


