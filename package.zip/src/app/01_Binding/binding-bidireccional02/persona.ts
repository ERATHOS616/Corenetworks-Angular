
export class Persona {
  nombre:string = "";
  edad:number = 0;
}
