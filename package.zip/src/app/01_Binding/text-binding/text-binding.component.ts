import { Component } from '@angular/core';

@Component({
  selector: 'app-text-binding',
  templateUrl: './text-binding.component.html',
  styleUrls: ['./text-binding.component.css']
})
export class TextBindingComponent{

  title = 'interpolacion';

    // PASO 1.
  // Creamos  variables ( propiedades de la clase) que usaremos en el .html
  // De momento todos los atributos serán PUBLIC para no tener que usar GETTERS

  nombre = "Angel";
  apellido1 = "García";
  edad = 30;

 // PASO 2. Función para escribir el nombre de la ciudad introducido por el usuario

 imprimeCiudad(ciudad:string) {}
}



