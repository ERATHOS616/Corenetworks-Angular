import { Component } from '@angular/core';

@Component({
  selector: 'app-practica-calculadora',
  templateUrl: './practica-calculadora.component.html',
  styleUrls: ['./practica-calculadora.component.css']
})
export class PracticaCalculadoraComponent{

  title = 'calculadora';
  num1:number = 0;
  num2:number = 0;
  resultado:number = 0;

  suma():void{
    this.resultado = this.num1 + this.num2;
  }

  resta():void{
    this.resultado = this.num1 - this.num2;
  }

  multiplica():void{
    this.resultado = this.num1 * this.num2;
  }

  divide():void{
    this.resultado = this.num1 / this.num2;
  }

}
