import { Component } from '@angular/core';

@Component({
  selector: 'app-event-binding',
  templateUrl: './event-binding.component.html',
  styleUrls: ['./event-binding.component.css']
})
export class EventBindingComponent{

  title = 'event_binding';
  mensaje = "Se ha pulsado el botón PULSAR";

  alerta(){
    alert(this.mensaje);
  }

  boton1(){
    alert("Se ha elegido la Opción 1");
  }

  boton2(){
    alert("Se ha elegido la Opción 2");
  }

  mouseOver(){
    alert("Se ha puesto el ratón sobre PULSAR");
  }

}
