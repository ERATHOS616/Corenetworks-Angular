import { Component } from '@angular/core';

@Component({
  selector: 'app-event-binding02',
  templateUrl: './event-binding02.component.html',
  styleUrls: ['./event-binding02.component.css']
})
export class EventBinding02Component{

//Variables
title = 'event_binding';
nombre='Angel';
apellido='García';

//private edad=16;
habilitar_property=false;
usurio='No hay un usuario registrado';

//Funciones
fn_alertaEdad(){
  alert('Introduzca aquí su edad!!');
}

fn_usuarioRegistrado(){
 this.usurio='Hay un usuario registrado';
}

fn_usuarioNoRegistrado(){
 this.usurio='No hay un usuario registrado';
}

}
