import { Component } from '@angular/core';

@Component({
  selector: 'app-binding-bidireccional',
  templateUrl: './binding-bidireccional.component.html',
  styleUrls: ['./binding-bidireccional.component.css']
})
export class BindingBidireccionalComponent{

  title = 'binding_bidireccional';
  name = "Manolo";

  //Paso 1
  // inputName(event:Event){
  //  this.name=((<HTMLInputElement>event.target).value);
  // }

  //Paso 2. Nos cargamos la función

}
