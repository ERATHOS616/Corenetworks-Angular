import { Component } from '@angular/core';

@Component({
  selector: 'app-ng-if',
  templateUrl: './ng-if.component.html',
  styleUrls: ['./ng-if.component.css']
})
export class NgIfComponent{

  title = 'app';
  heroeBorrado:any = "";

  heroes:string[]=["Spiderman", "Superman", "Ironman", "Batman"];

  borrar(){
    this.heroeBorrado = "Se ha borrado " + this.heroes.shift();
  }

}
