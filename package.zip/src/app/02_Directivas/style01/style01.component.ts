import { Component } from '@angular/core';

@Component({
  selector: 'app-style01',
  templateUrl: './style01.component.html',
  styleUrls: ['./style01.component.css']
})
export class Style01Component{

  title:string = "ngStyle";
  nombre:string = "";
  apellido:string = "";
  cargo:string = "";
  registro:boolean = false;
  registrado:string = "Usario registrado con éxito!!";

  registrar(){
    this.registro = true;
  }
}
