import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NgStyle03Component } from './ng-style03.component';

describe('NgStyle03Component', () => {
  let component: NgStyle03Component;
  let fixture: ComponentFixture<NgStyle03Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NgStyle03Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NgStyle03Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
