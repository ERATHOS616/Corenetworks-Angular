import { Component } from '@angular/core';

@Component({
  selector: 'app-ng-style03',
  templateUrl: './ng-style03.component.html',
  styleUrls: ['./ng-style03.component.css']
})
export class NgStyle03Component{

  size=30;
    presentacion={
    "background-color":"green",
    "color":"white",
    "width.px":"1000",
    "height.px":"200",
    "font-size.px":this.size,
    "display": "flex",
    "justify-content":"center",
    "align-items": "center"
  }

  agrandar() {
    this.size++;
    //Sintaxis para directivas individuales. Style binding.
    //Ejemplo:<p [style.background-color]="colorFondo">Color</p>
    this.presentacion["font-size.px"]=this.size;
  }

  reducir() {
    this.size--;
    //Sintaxis para directivas individuales.  Style binding.
    this.presentacion["font-size.px"]=this.size;
  }

}
