import { Component } from '@angular/core';

@Component({
  selector: 'app-ng-if02',
  templateUrl: './ng-if02.component.html',
  styleUrls: ['./ng-if02.component.css']
})
export class NgIf02Component{

  title = 'ngIf';
  registro = false;
  nombre:string = "";
  registrado = "Usuario registrado con éxito!! como ";

  registrar(){
    this.registro = true;
  }

}
