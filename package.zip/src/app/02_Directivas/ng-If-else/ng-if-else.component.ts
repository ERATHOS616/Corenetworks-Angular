import { Component } from '@angular/core';

@Component({
  selector: 'app-ng-if-else',
  templateUrl: './ng-if-else.component.html',
  styleUrls: ['./ng-if-else.component.css']
})
export class NgIfeLSEComponent{

  title = 'ngIfElse';
  registro = false;
  nombre:string = "";
  registrado = "Usuario registrado con éxito!! como ";

  registrar(){
    this.registro = true;
  }

}
