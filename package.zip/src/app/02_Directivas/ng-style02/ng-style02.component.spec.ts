import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NgStyle02Component } from './ng-style02.component';

describe('NgStyle02Component', () => {
  let component: NgStyle02Component;
  let fixture: ComponentFixture<NgStyle02Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NgStyle02Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NgStyle02Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
