import { Component } from '@angular/core';

@Component({
  selector: 'app-ng-style02',
  templateUrl: './ng-style02.component.html',
  styleUrls: ['./ng-style02.component.css']
})
export class NgStyle02Component{

miArray:string[]=["Usuario1", "Usuario2", "Usuario3", "Usuario4", "Usuario5"]
}
