
export class Usuario{
  nombre:string = "";
  apellido:string = "";
  login:string = "";
  password:string = "";

  constructor(nombre:string, apellido:string, login:string, password:string){
    this.nombre = nombre;
    this.apellido = apellido;
    this.login = login;
    this.password = password

  }
}
