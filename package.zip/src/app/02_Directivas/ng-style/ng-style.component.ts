import { Component } from '@angular/core';

@Component({
  selector: 'app-ng-style',
  templateUrl: './ng-style.component.html',
  styleUrls: ['./ng-style.component.css']
})
export class NgStyleComponent{

  title = 'ngStyle';
  registro = false;
  nombre:string = "";
  apellido:string = "";
  cargo:string = "";
  registrado = "Usuario registrado con éxito!! como ";

  registrar(){
    this.registro = true;
  }

}
