import { Component } from '@angular/core';

@Component({
  selector: 'app-ng-class',
  templateUrl: './ng-class.component.html',
  styleUrls: ['./ng-class.component.css']
})
export class NgClassComponent{

  title = 'ngClass';
  registro = false;
  nombre:string = "";
  apellido:string = "";
  cargo:string = "";
  registrado = "Usuario registrado con éxito!! como ";

  registrar(){
    this.registro = true;
  }

}
