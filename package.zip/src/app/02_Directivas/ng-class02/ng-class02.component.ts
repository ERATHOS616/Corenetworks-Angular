import { Component} from '@angular/core';

@Component({
  selector: 'app-ng-class02',
  templateUrl: './ng-class02.component.html',
  styleUrls: ['./ng-class02.component.css']
})
export class NgClass02Component {

  flag:boolean= false;

  cambiarFlag(){
    this.flag = !this.flag;
  }


}
