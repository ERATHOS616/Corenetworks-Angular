import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NgClass02Component } from './ng-class02.component';

describe('NgClass02Component', () => {
  let component: NgClass02Component;
  let fixture: ComponentFixture<NgClass02Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NgClass02Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NgClass02Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
