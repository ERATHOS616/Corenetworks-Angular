import { Component } from '@angular/core';

@Component({
  selector: 'app-ng-if03',
  templateUrl: './ng-if03.component.html',
  styleUrls: ['./ng-if03.component.css']
})
export class NgIf03Component{

  title = 'ngStyle';
  registro = false;
  nombre:string = "";
  apellido:string = "";
  cargo:string = "";
  registrado = "Usuario registrado con éxito!! como ";

  registrar(){
    this.registro = true;
  }

}
