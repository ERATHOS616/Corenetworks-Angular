import { Component } from '@angular/core';

@Component({
  selector: 'app-style02',
  templateUrl: './style02.component.html',
  styleUrls: ['./style02.component.css']
})
export class Style02Component {

  miArray:string[]=["Usuario1", "Usuario2","Usuario2","Usuario2"]


}
