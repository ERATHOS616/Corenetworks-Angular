import { Component } from '@angular/core';

@Component({
  selector: 'app-style03',
  templateUrl: './style03.component.html',
  styleUrls: ['./style03.component.css']
})
export class Style03Component {

  size:number = 30;

presentacion = {
  "background-color": "green",
  "color":"white",
  "width.px":"1000",
  "height.px":"200",
  "font-size.px":this.size,
  "display": "flex",
  "align-items": "center"
}

agrandar(){
    this.size++;

}

disminuir(){
  this.size--;

}
}
