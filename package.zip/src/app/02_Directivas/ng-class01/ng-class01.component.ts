import { Component } from '@angular/core';

@Component({
  selector: 'app-ng-class01',
  templateUrl: './ng-class01.component.html',
  styleUrls: ['./ng-class01.component.css']
})
export class NgClass01Component{
title:string = "ngClass";

nombre:string = "";
apellido:string = "";
cargo:string = "";
registro:boolean = false;
registrado:string = "Usario registrado con éxito!!";

registrar(){
  this.registro = true;
}
}
