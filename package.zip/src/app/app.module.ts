import { NgModule, Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { TextBindingComponent } from './01_Binding/text-binding/text-binding.component';
import { PropertyBindingComponent } from './01_Binding/property-binding/property-binding.component';
import { EventBindingComponent } from './01_Binding/event-binding/event-binding.component';
import { BindingBidireccionalComponent } from './01_Binding/binding-bidireccional/binding-bidireccional.component';
import { EventBinding02Component } from './01_Binding/event-binding02/event-binding02.component';
import { FormsModule } from '@angular/forms';
import { NgIfComponent } from './02_Directivas/ng-If/ng-if.component';
import { NgIf02Component } from './02_Directivas/ng-If02/ng-if02.component';
import { NgIfeLSEComponent } from './02_Directivas/ng-If-else/ng-if-else.component';
import { NgForComponent } from './02_Directivas/ng-for/ng-for.component';
import { BindingBidireccional02Component } from './01_Binding/binding-bidireccional02/binding-bidireccional02.component';
import { PracticaCalculadoraComponent } from './01_Binding/practica-calculadora/practica-calculadora.component';
import { NgIf03Component } from './02_Directivas/ng-if03/ng-if03.component';
import { PracticaDirectivasComponent } from './02_Directivas/practica-directivas/practica-directivas.component';
import { Style01Component } from './02_Directivas/style01/style01.component';
import { Style02Component } from './02_Directivas/style02/style02.component';
import { Style03Component } from './02_Directivas/style03/style03.component';
import { NgClass01Component } from './02_Directivas/ng-class01/ng-class01.component';
import { NgClass02Component } from './02_Directivas/ng-class02/ng-class02.component';
import { PadreComponent } from './03_Interaccion_componentes/padre/padre.component';
import { HijoComponent } from './03_Interaccion_componentes/padre/hijo/hijo.component';
import { Servicios1Component } from './04_Servicios/servicios1/servicios1.component';
import { Servicios2Component } from './04_Servicios/servicios2/servicios2.component';
import { AlertaService } from './04_Servicios/alerta.service';
import { Routes, RouterModule } from '@angular/router';
import { PipesComponent } from './06_pipes/pipes/pipes.component';
import { Pipes01Pipe } from './06_pipes/pipes/pipes01.pipe';





@NgModule({
  declarations: [
    AppComponent,
    TextBindingComponent,
    PropertyBindingComponent,
    EventBindingComponent,
    BindingBidireccionalComponent,
    EventBinding02Component,
    NgIfComponent,
    NgIf02Component,
    NgIfeLSEComponent,
    NgForComponent,
    BindingBidireccional02Component,
    PracticaCalculadoraComponent,
    NgIf03Component,
    PracticaDirectivasComponent,
    Style01Component,
    Style02Component,
    Style03Component,
    NgClass01Component,
    NgClass02Component,
    PadreComponent,
    HijoComponent,
    Servicios1Component,
    Servicios2Component,
    PipesComponent,
    Pipes01Pipe,


  ],

  imports: [
    BrowserModule,
    FormsModule
  ],

  providers: [AlertaService],
  bootstrap: [AppComponent]
})
export class AppModule { }
