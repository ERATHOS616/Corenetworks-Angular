import { Component, Input,  } from '@angular/core';
import { Usuario } from './usuario.model';



@Component({
  selector: 'app-hijo',
  templateUrl: './hijo.component.html',
  styleUrls: ['./hijo.component.css']
})

export class HijoComponent{


  //Debemos decirle al hijo que tiene que estar preparado para recibir dos variables del padre
  @Input() item_de_H:Usuario;
  @Input() i_de_H:number;



}
