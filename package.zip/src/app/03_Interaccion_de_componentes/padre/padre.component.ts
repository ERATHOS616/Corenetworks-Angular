import { Component } from '@angular/core';
import { Usuario } from './hijo/usuario.model';

@Component({
  selector: 'app-padre',
  templateUrl: './padre.component.html',
  styleUrls: ['./padre.component.css']
})
export class PadreComponent{

  titulo:string= "Práctica directivas";
  cuadroNombre:string = "";
  cuadroApellido:string = "";
  cuadroLogin:string = "";
  cuadroPassword:string = "";
  mostrar:boolean = false;

  arrayUsuarios:Usuario[]=[
    new Usuario("Angel", "García", "admin", "1234"),
    new Usuario("Manolo", "González", "man222", "2222"),
    new Usuario("Sara", "Jiménez", "sa3333", "3333")
  ]

  fn_agregaUsuario(){
    //Los datos los cogemos de los cuadros de texto del HTML
    let usuario1 = new Usuario(this.cuadroNombre, this.cuadroApellido, this.cuadroLogin, this.cuadroApellido);

    //Agregamos el nuevo usuario al array de usuarios
    this.arrayUsuarios.push(usuario1);
  }
}
