import { Component, Input} from '@angular/core';
import { Usuario } from '../../../02_Directivas/practica-directivas/usuario.model';

@Component({
  selector: 'app-hijo',
  templateUrl: './hijo.component.html',
  styleUrls: ['./hijo.component.css']
})
export class HijoComponent {

@Input() item_de_H:Usuario;
@Input() i_de_H:number;

}
